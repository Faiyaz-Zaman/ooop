/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bsccl.Main;

import java.io.Serializable;
import java.time.LocalDate;

/**
 *
 * @author User
 */
public class Employee extends User implements Serializable {

    public Employee(String userName, int userID, String password, String email, String contactNo, String address, LocalDate DOB, LocalDate DOJ) {
        super(userName, userID, password, email, contactNo, address, DOB, DOJ);
    }

    @Override
    public String toString(){
        return "username"+userName+"userID"+userID+"Password"+password+"email"+email+"Contact Number"+contactNo+"Address"+address+"Date Of Birth"+DOB+"Date Of Join"+DOJ;
        
    }
    
      

    
    
    

 
    
    
    
}
