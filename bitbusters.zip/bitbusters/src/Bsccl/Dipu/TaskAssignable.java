/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bscclsimulationoop.Dipu;

import java.io.Serializable;
import java.time.LocalDate;

/**
 *
 * @author DipuSD
 */
public class TaskAssignable implements Serializable{
    private LocalDate taskCreationDate;
    private String taskName;
    private String taskDescription;
    private int taskID;
    private int taskRank;

    public TaskAssignable(LocalDate taskCreationDate, String taskName, String taskDescription, int taskID, int taskRank) {
        this.taskCreationDate = taskCreationDate;
        this.taskName = taskName;
        this.taskDescription = taskDescription;
        this.taskID = taskID;
        this.taskRank = taskRank;
    }

    public LocalDate getTaskCreationDate() {
        return taskCreationDate;
    }

    public void setTaskCreationDate(LocalDate taskCreationDate) {
        this.taskCreationDate = taskCreationDate;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getTaskDescription() {
        return taskDescription;
    }

    public void setTaskDescription(String taskDescription) {
        this.taskDescription = taskDescription;
    }

    public int getTaskID() {
        return taskID;
    }

    public void setTaskID(int taskID) {
        this.taskID = taskID;
    }

    public int getTaskRank() {
        return taskRank;
    }

    public void setTaskRank(int taskRank) {
        this.taskRank = taskRank;
    }
    
    
    
    
}
