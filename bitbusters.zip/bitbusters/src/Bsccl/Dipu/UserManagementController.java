/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Bsccl.Dipu;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import Bsccl.Main.User;
/**
 * FXML Controller class
 *
 * @author DipuSD
 */
public class UserManagementController implements Initializable {

    @FXML
    private TableView<User> userListTable;
    @FXML
    private TableColumn<User, Integer> userIDTable;
    @FXML
    private TableColumn<User, String> userNameTable;
    @FXML
    private TableColumn<User, String> userTypeTable;
    @FXML
    private TableColumn<User, LocalDate> dateOfJoinTable;
    @FXML
    private TableColumn<User, Boolean> suspensionStatusTable;
    @FXML
    private ComboBox<String> sortByTableCombobox;
    @FXML
    private Button deleteUserButton;
    @FXML
    private Button resetPasswordButton;
    @FXML
    private Button suspendUserButton;
    @FXML
    private Button unsuspendUserButton;
    @FXML
    private Button editUserButton;
    
    //current user instance
    private User currentUser;
    
    private ObservableList<User> userList = FXCollections.observableArrayList();

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb){
        sortByTableCombobox.getItems().addAll(
                "All", 
                "Admin",
                "Engineer",
                "Customer",
                "TechnicalSupportOperator"
        );
        sortByTableCombobox.setValue("All");
        userIDTable.setCellValueFactory(new PropertyValueFactory<User, Integer>("userID"));
        userNameTable.setCellValueFactory(new PropertyValueFactory<User, String>("userName"));
        userTypeTable.setCellValueFactory(new PropertyValueFactory<User, String>("userType"));
        dateOfJoinTable.setCellValueFactory(new PropertyValueFactory<User, LocalDate>("dateOfJoin"));
        suspensionStatusTable.setCellValueFactory(new PropertyValueFactory<User, Boolean>("suspensionStatus"));
        try {
            sortByTableOnSelection(null);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UserManagementController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            Logger.getLogger(UserManagementController.class.getName()).log(Level.SEVERE, null, ex);
        }
        userListTable.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
    }    

    @FXML
    private void deleteUserButtonOnClick(ActionEvent event) throws IOException, FileNotFoundException, ClassNotFoundException, Exception {
        boolean userDeletionStatus = false;
        int index = userListTable.getSelectionModel().getSelectedIndex();
        int selectedUserID = Integer.parseInt(userIDTable.getCellData(index).toString());
        String selectedUserType = userTypeTable.getCellData(index).toString();
        
        if(currentUser instanceof Administrator){
            Administrator admin = (Administrator)currentUser;
            userDeletionStatus = admin.deleteUser(selectedUserID, selectedUserType);
        }
        
        if(userDeletionStatus){
            Alert a = new Alert(Alert.AlertType.INFORMATION);
            a.setContentText(selectedUserType+"Deleteion success");
            a.show();
        }
        else{
            Alert a = new Alert(Alert.AlertType.INFORMATION);
            a.setContentText(selectedUserType+"Deleteion Failed");
            a.show();
        }
        sortByTableOnSelection(null);
    }

    @FXML
    private void resetPassowrdButtonOnClick(ActionEvent event) throws IOException, FileNotFoundException, ClassNotFoundException {
        //getting user id from table
        int index = userListTable.getSelectionModel().getSelectedIndex();
        int selectedUserID = Integer.parseInt(userIDTable.getCellData(index).toString());
        //
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ResetPasswordByAdmin.fxml"));
        Parent root = loader.load();
        ///pass data
        ResetPassowrdByAdminController resetPassowrdByAdminController = loader.getController();
        resetPassowrdByAdminController.setCurrentPasswordHolderUser(ReadUserFile.getUserBYID(selectedUserID));
        resetPassowrdByAdminController.setCurrentUser(currentUser);

        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void suspendUserButtonOnClick(ActionEvent event) {
    }

    @FXML
    private void unsuspendUserButtonOnClick(ActionEvent event) {
    }

    @FXML
    private void editUserButtonOnClick(ActionEvent event) {
    }

    @FXML
    private void sortByTableOnSelection(ActionEvent event) throws IOException, FileNotFoundException, ClassNotFoundException, Exception {
        userList = Administrator.viewUserList(sortByTableCombobox.getValue());
        userListTable.setItems(userList);
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(User currentUser) {
        this.currentUser = currentUser;
    }
    
    

}
