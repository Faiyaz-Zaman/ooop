/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Bsccl.Dipu;

import java.net.URL;
import Bsccl.Main.User;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import jdk.nashorn.internal.runtime.arrays.ArrayLikeIterator;

/**
 * FXML Controller class
 *
 * @author DipuSD
 */
public class EngineerMangerAssignTaskController implements Initializable {

    @FXML
    private TableView<User> engineerListTableView;
    @FXML
    private TableColumn<User, Integer> engineerIdColumn;
    @FXML
    private TableColumn<User, String> engineerNameColumn;
    @FXML
    private TableColumn<User, Integer> engineerRankColumn;
    @FXML
    private TableView<TaskAssignable> taskLIstTableView;
    @FXML
    private TableColumn<TaskAssignable, Integer> taskIdColumn;
    @FXML
    private TableColumn<TaskAssignable, String> taskNameColumn;
    @FXML
    private TableColumn<TaskAssignable, Integer> taskRankColumn;
    @FXML
    private Button assignTaskButton;
    
    private User currentUser;
    
    private ObservableList<User> engineerList = FXCollections.observableArrayList();
    private ObservableList<TaskAssignable>taskList = FXCollections.observableArrayList();
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb){
        //setting engineerList table
        engineerIdColumn.setCellValueFactory(new PropertyValueFactory<User, Integer>("userID"));
        engineerNameColumn.setCellValueFactory(new PropertyValueFactory<User, String>("userName"));
        engineerRankColumn.setCellValueFactory(new PropertyValueFactory<User, Integer>("userRank"));
        engineerListTableView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        
        // setting task list table
        taskIdColumn.setCellValueFactory(new PropertyValueFactory<TaskAssignable, Integer>("taskID"));
        taskNameColumn.setCellValueFactory(new PropertyValueFactory<TaskAssignable, String>("taskName"));
        taskRankColumn.setCellValueFactory(new PropertyValueFactory<TaskAssignable, Integer>("taskRank"));
        taskLIstTableView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        
    }    

    @FXML
    private void assignTaskButtonOnClick(ActionEvent event) {
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(User currentUser) throws ClassNotFoundException, Exception {
        this.currentUser = currentUser;
        engineerList = Administrator.viewUserList("Engineer");
        engineerListTableView.setItems(engineerList);
        //
        if(currentUser instanceof NetworkEngineer){
            NetworkEngineer currentEngineer = (NetworkEngineer)currentUser;
            taskList = currentEngineer.viewAssignedTask(currentUser.getUserRank());
        }
        taskLIstTableView.setItems(taskList);
    }
    
    
    
}
