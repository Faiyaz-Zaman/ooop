/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Bsccl.Dipu;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author DipuSD
 */
public class CreateUserController implements Initializable {

    @FXML
    private TextField createUserName;
    @FXML
    private TextField createUserID;
    @FXML
    private TextField createUserPassword;
    @FXML
    private ComboBox<String> createUserType;
    @FXML
    private DatePicker createUserDOB;
    @FXML
    private DatePicker createUserDOJ;
    @FXML
    private Button createUserButton;
    @FXML
    private TextField createUserRank;
    @FXML
    private TextField createUserEmail;
    @FXML
    private TextField createUserAddress;
    @FXML
    private TextField createUserContacctNo;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        createUserType.getItems().addAll(
                "Admin",
                "Engineer",
                "Customer",
                "TechnicalSupportOperator");
        createUserRank.setDisable(true);
        createUserEmail.setDisable(true);
        createUserAddress.setDisable(true);
        createUserContacctNo.setDisable(true);
        
    }    

    @FXML
    private void createUserButtonOnClick(ActionEvent event) {
        String name = createUserName.getText();
        int userID = Integer.parseInt(createUserID.getText());
        String password= createUserPassword.getText();
        String userType = createUserType.getValue();
        LocalDate dob = createUserDOB.getValue();
        LocalDate doj = createUserDOJ.getValue();
        int rank;
        try{
            rank = Integer.parseInt(createUserRank.getText());
        }
        catch(NumberFormatException e){
            rank = 0; 
        }
        String email = createUserEmail.getText();
        String address = createUserAddress.getText();
        String contactNo = createUserContacctNo.getText();
        
        boolean accountCreationStatus = Administrator.createUser(name, userID, password, userType, dob, doj, rank, email, address, contactNo);
        if (accountCreationStatus){
            Alert a = new Alert(Alert.AlertType.INFORMATION);
            a.setContentText(userType+" creation sucessfull");
            a.show();
                }
        else{
            Alert a = new Alert(Alert.AlertType.ERROR);
            a.setContentText(userType+" creation fail");
            a.show();
        }       
    }

    @FXML
    private void UserTypeOnSelect(ActionEvent event) {
        switch (createUserType.getValue()) {
            case "Engineer":
                createUserRank.setDisable(false);
                createUserEmail.setDisable(true);
                createUserAddress.setDisable(true);
                createUserContacctNo.setDisable(true);
                
                break;
            case "Customer":
                createUserRank.setDisable(true);
                createUserEmail.setDisable(false);
                createUserAddress.setDisable(false);
                createUserContacctNo.setDisable(false);
                break;
            default:
                createUserRank.setDisable(true);
                createUserEmail.setDisable(true);
                createUserAddress.setDisable(true);
                createUserContacctNo.setDisable(true);
        }
    }
    
}
