/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bsccl.Dipu;
import Bsccl.Main.User;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author DipuSD
 */
public class Testing {
    public static void main(String[] args) throws IOException, ClassNotFoundException{
        String name = "Damian";
        String pass = "5689";
        String usertype = "Engineer";
        int userid = 23;
        int rank = 2;
        LocalDate dob = LocalDate.of(1999, 4, 5);
        LocalDate doj = LocalDate.of(2021, 2, 1);
//        User newUser = new Administrator(name, pass, usertype, userid, dob, doj);
        User newUser = new NetworkEngineer(rank, name, pass, usertype, userid, dob, doj);
        ArrayList<User> userlist;
        
        File f = new File("Users.bin");
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
        userlist = (ArrayList<User>)ois.readObject();
        ois.close();
        userlist.add(newUser);
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
        oos.writeObject(userlist);
        oos.flush();
        oos.close();


        
    }
}
