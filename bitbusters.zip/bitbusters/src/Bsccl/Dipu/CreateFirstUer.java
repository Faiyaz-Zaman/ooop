/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bsccl.Dipu;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import Bsccl.Main.User;

/**
 *
 * @author DipuSD
 */
public class CreateFirstUer {
    public static void main(String[] args) throws Exception{
        String name = "Admin";
        String pass = "1234";
        String usertype = "Admin";
        int userid = 1;
        int rank = 2;
        LocalDate dob = LocalDate.of(2002, 5, 5);
        LocalDate doj = LocalDate.of(2020, 2, 1);
        User newUser = new Administrator(name, pass, usertype, userid, dob, doj,rank);
//        User newUser = new NetworkEngineer(rank, name, pass, usertype, userid, dob, doj);
        ArrayList<User> userlist = new ArrayList<User>();
        File f = new File("Users.bin");
        f.createNewFile();
        userlist.add(newUser);
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
        oos.writeObject(userlist);
        oos.flush();
        oos.close();
        
    }
}
