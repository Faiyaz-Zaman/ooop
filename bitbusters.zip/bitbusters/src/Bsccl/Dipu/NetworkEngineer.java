/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bsccl.Dipu;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import Bsccl.Main.User;

/**
 *
 * @author DipuSD
 */
public class NetworkEngineer extends User{
    private ArrayList<TaskAssignable>assignedTaslLIst = new ArrayList<TaskAssignable>();

    public NetworkEngineer(int rank, String userName, String password, String userType, int userID, LocalDate dateOfBirth, LocalDate dateOfJoin) {
        super(userName, password, userType, userID, dateOfBirth, dateOfJoin, rank);
    }
   
    private boolean solveTask(){
        return true;//do later
    }
    
    private boolean submitProjectCompletionReport(){
        return true;//do later
    }
    
    private boolean submitMaintenanceReport(){
        return true;//do later
    }
    
    private boolean assignTaskToSubordinate(){
        return true;
    }
    
    protected ObservableList<TaskAssignable> viewAssignedTask(int rank) throws IOException, FileNotFoundException, ClassNotFoundException{
        ObservableList<TaskAssignable> returnTaskList = FXCollections.observableArrayList();
        if(rank == 3){
            ArrayList<TaskAssignable> alltask = ReadTaskListFile.getAllTask();
            for(TaskAssignable t: alltask){
                returnTaskList.add(t);
            }
        
            return returnTaskList;
        }
        else{
            for(TaskAssignable t: assignedTaslLIst){
                returnTaskList.add(t);
            }
            return returnTaskList;
        }
    }
    
    private ArrayList<?> accessMeintanaceReport(){
        return null;
    }
    
    private void accessOngoingProject(){
        //do later change the return type
    }
    
    private void completeProject(){
        //do later change the return type
    }

    public ArrayList<TaskAssignable> getAssignedTaslLIst() {
        return assignedTaslLIst;
    }

    public void setAssignedTaslLIst(ArrayList<TaskAssignable> assignedTaslLIst) {
        this.assignedTaslLIst = assignedTaslLIst;
    }
    
    
}
