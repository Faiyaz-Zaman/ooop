/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bsccl.Dipu;
import Bsccl.Main.User;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

/**
 *
 * @author DipuSD
 */
public class WriteNewUser {
    public static boolean writeUser(User newUser){
        ArrayList<User>userList;
        try {
            File f = new File("Users.bin");
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
            userList = (ArrayList<User>)ois.readObject();
            ois.close();
            userList.add(newUser);
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
            oos.writeObject(userList);
            oos.flush();
            oos.close();
            return true;
        
        } catch (Exception e) {
            return false;
        }
    }
}
