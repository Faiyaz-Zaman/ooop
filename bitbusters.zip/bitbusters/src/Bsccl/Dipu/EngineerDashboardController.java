/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Bsccl.Dipu;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import Bsccl.Main.User;
/**
 * FXML Controller class
 *
 * @author DipuSD
 */
public class EngineerDashboardController implements Initializable {

    @FXML
    private BorderPane engineerDashboardborderpane;
    @FXML
    private Label dashboardName;
    @FXML
    private Label dashboardID;
    @FXML
    private Label dashboardDateOfBirth;
    @FXML
    private Label dashboardTotalAssignedTask;
    @FXML
    private Label dashboardCurrentAssignedProject;
    
    private User currentUser;
    @FXML
    private Label dashboardRank;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void viewDashboardOnClick(ActionEvent event) throws IOException{
        FXMLLoader loader = new FXMLLoader(getClass().getResource("EngineerDashboard.fxml"));
        Parent root = loader.load();
        //Passing data
        EngineerDashboardController engineerDashboardController = loader.getController();
        engineerDashboardController.setCurrentUser(getCurrentUser());
        
        //
        Stage st = (Stage)(((Node)engineerDashboardborderpane).getScene().getWindow());
        Scene scene = new Scene(root);
        st.setScene(scene);
        st.show();
    }

    @FXML
    private void viewTaskOnClick(ActionEvent event) throws IOException, Exception {
        if(currentUser.getUserRank() == 3){
            FXMLLoader loader = new FXMLLoader(getClass().getResource("EngineerMangerAssignTask.fxml"));
            Parent root = loader.load();
            //Passing data
            EngineerMangerAssignTaskController engineerMangerAssignTaskController = loader.getController();
            engineerMangerAssignTaskController.setCurrentUser(currentUser);
            //
            engineerDashboardborderpane.setCenter(root);
            
        }
        else{
            FXMLLoader loader = new FXMLLoader(getClass().getResource("EngineerViewAssignedTask.fxml"));
            Parent root = loader.load();
            //Passing data
            EngineerViewAssignedTaskController engineerViewAssignedTaskController = loader.getController();
            engineerViewAssignedTaskController.setCurrentUser(currentUser);
            //
            engineerDashboardborderpane.setCenter(root);
            
        }
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(User currentUser) {
        this.currentUser = currentUser;
        dashboardName.setText(dashboardName.getText()+" "+currentUser.getUserName());
        dashboardID.setText(dashboardID.getText()+" "+currentUser.getUserID());
        dashboardDateOfBirth.setText(dashboardDateOfBirth.getText()+" "+currentUser.getDateOfBirth());
        dashboardRank.setText(dashboardRank.getText()+" "+currentUser.getUserRank());
       
    }
    
    
}
