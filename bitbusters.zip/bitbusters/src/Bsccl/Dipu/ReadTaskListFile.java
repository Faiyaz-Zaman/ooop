/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bscclsimulationoop.Dipu;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;


/**
 *
 * @author DipuSD
 */
public class ReadTaskListFile {
    public static ArrayList<TaskAssignable> getAllTask() throws FileNotFoundException, IOException, ClassNotFoundException{
        ArrayList<TaskAssignable>allTask;
        File f = new File("EngineersTaskList.bin");
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
        allTask = (ArrayList<TaskAssignable>)ois.readObject();
        ois.close();

        return allTask;
    }
}
