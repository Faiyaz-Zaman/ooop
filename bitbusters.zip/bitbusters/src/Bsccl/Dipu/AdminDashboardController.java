/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Bsccl.Dipu;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import Bsccl.Main.User;

/**
 * FXML Controller class
 *
 * @author DipuSD
 */
public class AdminDashboardController implements Initializable {

    @FXML
    private Label dashBoardName;
    @FXML
    private Label dashboardID;
    @FXML
    private Label dashBoardDateOFBirth;
    @FXML
    private Label dashboardTotalUser;
    @FXML
    private Label dashboardTotalSuspenedUser;
    @FXML
    private BorderPane adminDashboardBorderPane;
    
    private User currentUser;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void viewDashboardOnClick(ActionEvent event) throws IOException{
        FXMLLoader loader = new FXMLLoader(getClass().getResource("AdminDashboard.fxml"));
        Parent root = loader.load();
        //Passing data
        AdminDashboardController adminDashboardController = loader.getController();
        adminDashboardController.setCurrentUser(getCurrentUser());
        
        //
        Stage st = (Stage)(((Node)adminDashboardBorderPane).getScene().getWindow());
        Scene scene = new Scene(root);
        st.setScene(scene);
        st.showAndWait();
    }

    @FXML
    private void createUserOnClick(ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("CreateUser.fxml"));
        adminDashboardBorderPane.setCenter(root);
       
    }

    @FXML
    private void userManagementOnClick(ActionEvent event) throws IOException{
         FXMLLoader loader = new FXMLLoader(getClass().getResource("UserManagement.fxml"));
         Parent root = loader.load();
         //passing data
         UserManagementController userManagementController = loader.getController();
         userManagementController.setCurrentUser(currentUser);
         adminDashboardBorderPane.setCenter(root);
    }

    @FXML
    private void sendNotificationOnClick(ActionEvent event) {
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(User currentUser) {
        this.currentUser = currentUser;
        dashBoardName.setText(dashBoardName.getText()+" "+currentUser.getUserName());
        dashboardID.setText(dashboardID.getText()+" "+currentUser.getUserID());
        dashBoardDateOFBirth.setText(dashBoardDateOFBirth.getText()+" "+currentUser.getDOB());
    }
    
    
}
