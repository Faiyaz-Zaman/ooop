/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bsccl.Dipu;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import Bsccl.Main.User;

/**
 *
 * @author DipuSD
 */
public class ReadUserFile {
    public static ArrayList<User> getSpecificUsers(String userType) throws Exception{
        ArrayList<User>userlist = new ArrayList<User>();
        ArrayList<User>retrivedlist;
        File f = new File("Users.bin");
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
        retrivedlist = (ArrayList<User>)ois.readObject();
        for(User user: retrivedlist){
            if(user.getUserType().equals(userType)){
                userlist.add(user);
            }
        }
        return userlist;
    }
    
    public static ArrayList<User> getAllUsers() throws FileNotFoundException, IOException, ClassNotFoundException{
        ArrayList<User> userlist;
        File f = new File("Users.bin");
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
        userlist = (ArrayList<User>)ois.readObject();
        ois.close();
        return userlist;
    }
    
    public static User getUserBYID(int userID) throws FileNotFoundException, IOException, ClassNotFoundException{
        ArrayList<User>retrivedlist;
        File f = new File("Users.bin");
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
        retrivedlist = (ArrayList<User>)ois.readObject();
        for(User user: retrivedlist){
            if(user.getUserID() == userID){
                return user;
            }
        }
        return null;
    }
}
