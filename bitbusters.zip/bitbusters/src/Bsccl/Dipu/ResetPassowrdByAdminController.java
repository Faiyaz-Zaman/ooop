/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Bsccl.Dipu;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import Bsccl.Main.User;

/**
 * FXML Controller class
 *
 * @author DipuSD
 */
public class ResetPassowrdByAdminController implements Initializable {

    @FXML
    private Label resetPassowrdLabel;
    @FXML
    private TextField newPasswordTextField;
    @FXML
    private TextArea oldPasswordTextArea;
    @FXML
    private Button resetPasswordButton;
    
    private User currentUser;
    private User currentPasswordHolderUser;
    
    private ArrayList<User>allUserList;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void resetPasswordButtonOnClick(ActionEvent event) throws IOException, FileNotFoundException, ClassNotFoundException {
        allUserList = ReadUserFile.getAllUsers();
        boolean passwrodChangeStatus = false;
        boolean fileOverWriteStatus = false;
        String newPassword = newPasswordTextField.getText();
        if(currentUser instanceof Administrator){
            Administrator curentAdmin = (Administrator)currentUser;
            for(User u: allUserList){
                if(u.getUserID() == currentPasswordHolderUser.getUserID()){
                  passwrodChangeStatus = curentAdmin.resetPassword(u, newPassword);
                  fileOverWriteStatus = DeleteUserHelper.overWriteNewUserList(allUserList);
                  break;
                }
            }
        }
        if(passwrodChangeStatus && fileOverWriteStatus){
            Alert a = new Alert(Alert.AlertType.INFORMATION);
            a.setContentText(currentPasswordHolderUser.getUserName()+"Password reset succesful");
            a.show();
        }
        else{
            Alert a = new Alert(Alert.AlertType.INFORMATION);
            a.setContentText(currentPasswordHolderUser.getUserName()+"Password reset failed");
            a.show();
        }
        
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(User currentUser) {
        this.currentUser = currentUser;
    }

    public User getCurrentPasswordHolderUser() {
        return currentPasswordHolderUser;
    }

    public void setCurrentPasswordHolderUser(User currentPasswordHolderUser) {
        this.currentPasswordHolderUser = currentPasswordHolderUser;
        resetPassowrdLabel.setText(resetPassowrdLabel.getText()+" "+this.currentPasswordHolderUser.getUserName());
        oldPasswordTextArea.setEditable(false);
        oldPasswordTextArea.setText(this.currentPasswordHolderUser.getPassword());
    }
    
    
    
}
