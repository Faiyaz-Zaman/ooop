/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bsccl.Dipu;
import Bsccl.Main.User;
import Bsccl.Faiyaz.Customer.Customer;
import Bsccl.Faiyaz.Customer.Technicalsupportoperatoruser;

import java.time.LocalDate;

/**
 *
 * @author DipuSD
 */
public class CreateUserHelper {
    public static boolean createNewAdmin(String name, String password, String userType, int userID, LocalDate DoB, LocalDate DOJ,int rank){
        User newAdmin = new Administrator(name, password, userType, userID, DoB, DOJ,rank);
        return WriteNewUser.writeUser(newAdmin);
        
    }
    
    public static boolean createNewEngineer(int rank, String userName, String password, String userType, int userID, LocalDate dateOfBirth, LocalDate dateOfJoin){
        User newEngineer = new NetworkEngineer(rank, userName, password, userType, userID, dateOfBirth, dateOfJoin);
        return WriteNewUser.writeUser(newEngineer);
    }
    
    public static boolean createNewCustomer(String email, String address, String contactno, String userName, String password, String userType, int userID, LocalDate dateOfBirth, LocalDate dateOfJoin){
       User newCustomer = new Customer(String userName, String password, String userType, int userID, LocalDate dateOfBirth, LocalDate dateOfJoin, String email, String contactNo, String address){
       return WriteNewUser.writeUser(newCustomer);
    }
    
    public static boolean createNewTechnicalSupportOperator(String userName, String password, String userType, int userID, LocalDate dateOfBirth, LocalDate dateOfJoin){
       User newTechincalSupportOperator = new Technicalsupportoperatoruser(userName, password, userType, userID, dateOfBirth, dateOfJoin);
       return WriteNewUser.writeUser(newTechincalSupportOperator);
    }
}
