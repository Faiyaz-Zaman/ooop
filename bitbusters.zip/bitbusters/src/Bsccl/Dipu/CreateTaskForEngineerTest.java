/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bscclsimulationoop.Dipu;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author DipuSD
 */
public class CreateTaskForEngineerTest {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
           createFirstTask();
           createNewTask();
           showAllTask();
    }
    
    public static void createFirstTask() throws IOException{
        ArrayList<TaskAssignable>allTask = new ArrayList<TaskAssignable>();
        LocalDate currentDate = LocalDate.now();
        String taskName = "Fix junction box";
        String taskDescription = "hello you have to fix the junction box at baridhara";
        int taskID = 1;
        int taskRank = 1;
        
        TaskAssignable newTask = new TaskAssignable(currentDate, taskName, taskDescription, taskID, taskRank);
        
        File f = new File("EngineersTaskList.bin");
        f.createNewFile();
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
        allTask.add(newTask);
        oos.writeObject(allTask);
        oos.flush();
        oos.close();
    }
    
    public static void createNewTask() throws IOException, ClassNotFoundException{
        ArrayList<TaskAssignable>allTask;
        LocalDate currentDate = LocalDate.now();
        String taskName = "Replace Wire";
        String taskDescription = "hello you have to replace wire at the junction box at baridhara";
        int taskID = 2;
        int taskRank = 1;
        
        TaskAssignable newTask = new TaskAssignable(currentDate, taskName, taskDescription, taskID, taskRank);
        
        File f = new File("EngineersTaskList.bin");
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
        allTask = (ArrayList < TaskAssignable >)ois.readObject();
        ois.close();
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
        allTask.add(newTask);
        oos.writeObject(allTask);
        oos.flush();
        oos.close();
        
    }
    
    public static void showAllTask() throws FileNotFoundException, IOException, ClassNotFoundException{
        ArrayList<TaskAssignable>allTask;
        File f = new File("EngineersTaskList.bin");
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
        allTask = (ArrayList<TaskAssignable>)ois.readObject();
        ois.close();
        for(TaskAssignable t: allTask){
            System.out.println(t.getTaskID()+" "+t.getTaskName());
        }
        
                
    }
    
}
