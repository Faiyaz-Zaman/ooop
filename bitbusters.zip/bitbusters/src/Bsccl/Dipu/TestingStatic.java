/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bsccl.Dipu;
import Bsccl.Main.User;

import java.util.ArrayList;

/**
 *
 * @author DipuSD
 */
public class TestingStatic {
    public static void main(String[] args) throws Exception{
        ArrayList<User>ulist = ReadUserFile.getSpecificUsers("Admin");
        for(User u: ulist){
            System.out.println(u.getUserName()+" "+u.getUserID());
        }
    }
    
}
