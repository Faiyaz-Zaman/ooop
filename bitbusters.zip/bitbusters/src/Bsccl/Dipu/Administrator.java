/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bsccl.Dipu;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import Bsccl.Main.User;

/**
 *
 * @author DipuSD
 */
public class Administrator extends User{

    public Administrator(String userName, String password, String userType, int userID, LocalDate dateOfBirth, LocalDate dateOfJoin, int userRank) {
        super(userName, password, userType, userID, dateOfBirth, dateOfJoin, userRank);
    }

// /*   public Administrator() {

    
    
    
    ;
    

//    }*/
    public static boolean createUser(String name, int userID, String password, String userType, LocalDate dob, LocalDate doj, int rank, String email, String address, String contactNo) {
        switch (userType) {
            case "Admin":
                boolean adminStatus = CreateUserHelper.createNewAdmin(name, password, userType, userID, dob, doj,rank);
                return adminStatus;

            case "Engineer":
                boolean engineerStatus = CreateUserHelper.createNewEngineer(rank, name, password, userType, userID, dob, doj);
                return engineerStatus;
                
            case "Customer":
                boolean customerStatus = CreateUserHelper.createNewCustomer(email,address, contactNo, name, password, userType, userID, dob, doj);
                return customerStatus;
                
            case "TechnicalSupportOperator":
                boolean technicalSupportStatus = CreateUserHelper.createNewTechnicalSupportOperator(name, password, userType, userID, dob, doj);
                return technicalSupportStatus;
                
            default:
                throw new AssertionError();
        }
    }
    protected boolean deleteUser(int userID, String userType) throws IOException, FileNotFoundException, ClassNotFoundException{
        ArrayList<User> allUser = ReadUserFile.getAllUsers();
        for(User u: allUser){
            if(u.getUserID() == userID && u.getUserType().equals(userType)){
                allUser.remove(u);
                return DeleteUserHelper.overWriteNewUserList(allUser);
            }
        }
        return false;
    }
    public static ObservableList<User> viewUserList(String returnUserType) throws IOException, FileNotFoundException, ClassNotFoundException, Exception{
        ObservableList<User> userList = FXCollections.observableArrayList();
        switch (returnUserType) {
            case "All":
                userList = obListConverter(ReadUserFile.getAllUsers());
                break;
            case "Admin":
                userList = obListConverter(ReadUserFile.getSpecificUsers("Admin"));
                break;
            case "Engineer":
                userList = obListConverter(ReadUserFile.getSpecificUsers("Engineer"));
                break;
            case "Customer":
                userList = obListConverter(ReadUserFile.getSpecificUsers("Customer"));
                break;
                case "TechnicalSupportOperator":
                userList = obListConverter(ReadUserFile.getSpecificUsers("TechnicalSupportOperator"));
                break;
            default:
                throw new AssertionError();
        }
        return userList;
    }
    private boolean setSuspensionStatusOfUser(User userObj, boolean suspensionStatus){
        if(userObj.isSuspensionStatus() == suspensionStatus){
            return false;
        }
        else{
            userObj.setSuspensionStatus(suspensionStatus);
            return true;
        }
    }
    
    private void updateEmployeeInformation(User userObj){
        ///update later
    }
    
    private void sendNotification(){
        //update later
    }
    private void backupFiles(){
        
    }
    protected boolean resetPassword(User userObj, String newPassword){
        if(newPassword.equals(userObj.getPassword())){
            return false;
        }
        else{
            userObj.setPassword(newPassword);
            return true;
        }
    }
    public static ObservableList<User> obListConverter(ArrayList<User>toBeConverted){
       ObservableList<User>convertedList = FXCollections.observableArrayList();
       for(User u: toBeConverted){
           convertedList.add(u);
       } 
       return convertedList;
    }
}
