/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bsccl.Dipu;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import Bsccl.Main.User;

/**
 *
 * @author DipuSD
 */
public class DeleteUserHelper {
    public static boolean overWriteNewUserList(ArrayList<User> modifiedUserList) throws FileNotFoundException, IOException{
        try{
            File f = new File("Users.bin");
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
            oos.writeObject(modifiedUserList);
            oos.flush();
            oos.close();
            return true;
        }
        catch(Exception e){
            return false;
        }
        
    }
}
