/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Bsccl.Faiyaz.Customer;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import Bsccl.Main.User;
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author User
 */
public class SupportingticketsController implements Initializable {

    @FXML
    private TextArea detailstxtarea;
    @FXML
    private ComboBox<String> typeofproblemcombobox;
    @FXML
    private Customer customer;
    private User user;
    @FXML
    private Label nametxtlabel;
    @FXML
    private Label idlabeltxt;
    Alert a = new Alert(Alert.AlertType.INFORMATION);
    Alert fail = new Alert(Alert.AlertType.INFORMATION);
    Alert failure = new Alert(Alert.AlertType.INFORMATION);
     Alert nullerror = new Alert(Alert.AlertType.INFORMATION);
          

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        typeofproblemcombobox.getItems().addAll("Network related Issue","Physical problem","Server problem");
        // TODO
    }    


        
        
    
         
    

    public void setCustomer(Customer customer) {
        this.customer = customer;
        nametxtlabel.setText(nametxtlabel.getText()+" "+customer.getUserName());
        idlabeltxt.setText(idlabeltxt.getText()+" "+Integer.toString(customer.getUserID()));
//        
    }

    public Customer getCustomer() {
        return customer;
    }

  
    

    @FXML
    private void returnbutton(ActionEvent event) throws IOException {
        Parent patientDashboard = null;
        FXMLLoader patientLoader = new FXMLLoader(getClass().getResource("customerdashboard.fxml"));
        patientDashboard = (Parent) patientLoader.load();
        Scene patientScene = new Scene(patientDashboard);

        customerdashboardController p = patientLoader.getController();
        p.setCustomer(customer);

        Stage patientStage = (Stage)((Node)event.getSource()).getScene().getWindow(); 
        patientStage.setScene(patientScene);
        patientStage.show();
    }

    @FXML
    private void submitticketbutton(ActionEvent event) {  
         String detail = detailstxtarea.getText();
         if(detail==null){
             nullerror.setContentText("Choose a type of problem");
             nullerror.show();
             
         }
         String problemcombobox = typeofproblemcombobox.getSelectionModel().getSelectedItem();
          if (detail==null|detail.isEmpty()){
          fail.setContentText("Please write something");
            fail.show();
          return;}
          System.out.println("Entered info: "+detail+", "+problemcombobox);
//        switch (problemcombobox) {
//            case "Network related Issue":
//                detailstxtarea.setText(idlabeltxt.getText()+","+customer.getUserName()+","+problemcombobox+"\n");
//                break;
//            case "Physical problem":
//               detailstxtarea.setText(idlabeltxt.getText()+","+customer.getUserName()+","+problemcombobox+"\n");
//                
//                break;
//            default:
//                detailstxtarea.setText(idlabeltxt.getText()+","+customer.getUserName()+","+problemcombobox+"\n");
//                break;
//                
//        }
        if (this.customer.makesupporttickets(problemcombobox, detail,Integer.parseInt(idlabeltxt.getText()))){ 
            a.setContentText("Your ticket is sent");
            a.show(); }
        else {failure.show();
        
         }
    }
    
}
