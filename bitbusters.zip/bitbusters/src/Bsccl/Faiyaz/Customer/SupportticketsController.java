/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Bsccl.Faiyaz.Customer;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.ToggleGroup;

/**
 * FXML Controller class
 *
 * @author User
 */
public class SupportticketsController implements Initializable {

    @FXML
    private RadioButton solvedradiobutton;
    @FXML
    private ToggleGroup filter;
    @FXML
    private RadioButton pendingradiobutton;
    @FXML
    private RadioButton allradiobutton;
    @FXML
    private TableView<SupportTickets> supportticketstable;
    @FXML
    private TableColumn<SupportTickets, Integer> customerid;
    @FXML
    private TableColumn<SupportTickets, String> customername;
    @FXML
    private TableColumn<SupportTickets, String> typeofproblem;
    @FXML
    private TableColumn<SupportTickets, String> problemdescription;
    @FXML
    private TableColumn<SupportTickets, String> statustablecolumn;
    private Technicalsupportoperatoruser tsp;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        // TODO
    }    

    public void setTsp(Technicalsupportoperatoruser tsp) {
        this.tsp = tsp;
    }

    public Technicalsupportoperatoruser getTsp() {
        return tsp;
    }

    @FXML
    private void applyfilter(ActionEvent event) {
    }

    @FXML
    private void returnbutton(ActionEvent event) {
    }


    @FXML
    private void sendtonetworkengineers(ActionEvent event) {
    }

    @FXML
    private void sendnotificationtocustomerbutton(ActionEvent event) {
    }
    
}
