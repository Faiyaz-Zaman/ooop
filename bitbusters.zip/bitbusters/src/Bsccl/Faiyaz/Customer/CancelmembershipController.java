/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Bsccl.Faiyaz.Customer;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import Bsccl.Main.User;
import javafx.scene.control.Alert;

/**
 * FXML Controller class
 *
 * @author User
 */
public class CancelmembershipController implements Initializable {

    @FXML
    private Label idlabeltxt;
    @FXML
    private Label namelabeltxt;
    @FXML
    private TextArea reasontxtarea;
    private Customer customer;
     Alert a = new Alert(Alert.AlertType.INFORMATION);
     Alert failure = new Alert(Alert.AlertType.INFORMATION);
     

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }  

   

    public void setCustomer(Customer customer) {
        this.customer = customer;
        namelabeltxt.setText(namelabeltxt.getText()+" "+customer.getUserName());
        idlabeltxt.setText(idlabeltxt.getText()+" "+customer.getUserID());
    }

    public Customer getCustomer() {
        return customer;
        
    }

    

    
    


    @FXML
    private void returnbutton(ActionEvent event) {
    }

    @FXML
    private void cancelmembershipbutton(ActionEvent event) {
        String reason = reasontxtarea.getText();
        System.out.println(reason);
        if (this.customer.cancelmembership(reason)){
            a.setContentText("Your ticket is sent");
            a.show(); }
      
    }
    
}
