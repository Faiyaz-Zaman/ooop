/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bsccl.Faiyaz.Customer;

import java.io.Serializable;

/**
 *
 * @author User
 */
public class cancelmember implements Serializable {
    private String reason;
    private int userid;

    public String getReason() {
        return reason;
    }

    

    public int getUserid() {
        return userid;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

   

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public cancelmember(String reason,  int userid) {
        this.reason = reason;
      
        this.userid = userid;
    }
    
    @Override
    public String toString(){
        return "User ID"+userid+",reason"+reason;
        
    }
}
