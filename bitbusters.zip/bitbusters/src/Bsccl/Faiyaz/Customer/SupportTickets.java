/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bsccl.Faiyaz.Customer;

import java.io.Serializable;

/**
 *
 * @author User
 */
public class SupportTickets implements Serializable {
    private static final long serialVersionUID = 15L;
     public String problemtype;
     private String details;
     private int userid;
    // private String username;

    public String getProblemtype() {
        return problemtype;
    }

    public void setProblemtype(String problemtype) {
        this.problemtype = problemtype;
    }

    

   

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

   

    public int getUserid() {
        return userid;
    }

   // public String getUsername() {
    //    return username;
    //}

   
    

    public void setUserid(int userid) {
        this.userid = userid;
    }

//    public void setUsername(String username) {
//        this.username = username;
//    }

    public SupportTickets(String problemtype, String details, int userid) {
        this.problemtype = problemtype;
        this.details = details;
        this.userid = userid;
//        this.username = username;
    }
     public String toString() {
        return "supportticket=" + "usertype=" + problemtype+ ", details=" + details +  "userid"+userid;
    }
    
   
    
    
}
